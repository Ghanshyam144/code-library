#include <windows.h>
#include <GL/glut.h>

void display() {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glOrtho(-4, 4, -4, 4, -4, 4);

    // Rotate cuboid slightly for better view
    glRotatef(30, 1.0f, 0.0f, 0.0f);
    glRotatef(30, 0.0f, 1.0f, 0.0f);

    glBegin(GL_QUADS);
    // Front face
    glColor3f(1.0f, 0.4f, 0.3f);  // Red
    glVertex3f(-2.0f, -1.0f, 1.0f);
    glVertex3f(2.0f, -1.0f, 1.0f);
    glVertex3f(2.0f, 1.0f, 1.0f);
    glVertex3f(-2.0f, 1.0f, 1.0f);

    // Back face
    glColor3f(0.0f, 1.0f, 0.0f);  // Green
    glVertex3f(-2.0f, -1.0f, -1.0f);
    glVertex3f(-2.0f, 1.0f, -1.0f);
    glVertex3f(2.0f, 1.0f, -1.0f);
    glVertex3f(2.0f, -1.0f, -1.0f);

    // Top face
    glColor3f(0.0f, 0.0f, 1.0f);  // Blue
    glVertex3f(-2.0f, 1.0f, -1.0f);
    glVertex3f(-2.0f, 1.0f, 1.0f);
    glVertex3f(2.0f, 1.0f, 1.0f);
    glVertex3f(2.0f, 1.0f, -1.0f);

    // Bottom face
    glColor3f(1.0f, 1.0f, 0.0f);  // Yellow
    glVertex3f(-2.0f, -1.0f, -1.0f);
    glVertex3f(2.0f, -1.0f, -1.0f);
    glVertex3f(2.0f, -1.0f, 1.0f);
    glVertex3f(-2.0f, -1.0f, 1.0f);

    // Right face
    glColor3f(1.0f, 0.0f, 1.0f);  // Purple
    glVertex3f(2.0f, -1.0f, -1.0f);
    glVertex3f(2.0f, 1.0f, -1.0f);
    glVertex3f(2.0f, 1.0f, 1.0f);
    glVertex3f(2.0f, -1.0f, 1.0f);

    // Left face
    glColor3f(0.0f, 1.0f, 1.0f);  // Cyan
    glVertex3f(-2.0f, -1.0f, -1.0f);
    glVertex3f(-2.0f, -1.0f, 1.0f);
    glVertex3f(-2.0f, 1.0f, 1.0f);
    glVertex3f(-2.0f, 1.0f, -1.0f);

    glEnd();

    glFlush();
    glutSwapBuffers();
}

void init() {
    glEnable(GL_DEPTH_TEST);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("3D Elongated Cuboid");
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(50, 50);
    glutDisplayFunc(display);
    init();
    glutMainLoop();

    return 0;
}
